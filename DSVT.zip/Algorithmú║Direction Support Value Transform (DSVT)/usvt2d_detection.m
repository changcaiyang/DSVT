function [CD,B]=usvt2d_detection(img,J,md)
mt=2;
switch mt
    case 1
C = usvt2D(img, J); 
Ct = C;
CD1=C{1}{3}.*0+1;CD2=CD1;CD3=CD1;B1=CD1.*0;
for s = 1:J
    CD1=CD1.*Ct{s}{1}; 
    CD2=CD2.*Ct{s}{2}; 
    CD3=CD3.*Ct{s}{3};
end

CD=CD3;B=CD;
switch md
    case 1
        CD = CD1;B=CD2;
    case 2
        CD = CD2;B=CD1;
end

% figure(6);surf(CD);
% 
    case 2
[C,p] = usvt2D(img, J); 
Ct = C;
for s = 1:J
    p{s}=p{s}+(p{s}==0);tmp = Ct{s}{1}./p{s};Nsig = median(abs(tmp(:)))/0.6745;
    Ct{s}{1}=HT(Ct{s}{1}./p{s},Nsig); Ct{s}{1}=Ct{s}{1}.*p{s};
%     tmp = Ct{s}{2}./p{s};Nsig = median(abs(tmp(:)))/0.6745;
    Ct{s}{2}=HT(Ct{s}{2}./p{s},Nsig);Ct{s}{2}=Ct{s}{2}.*p{s};
%     tmp = Ct{s}{3}./p{s};Nsig = median(abs(tmp(:)))/0.6745;
    Ct{s}{3}=HT(Ct{s}{3}./p{s},Nsig);Ct{s}{3}=Ct{s}{3}.*p{s}; 
end

CD1=C{1}{3}.*0+1;CD2=CD1;CD3=CD1;B1=CD1.*0;
for s = 1:J
%     CD1=CD1.*Ct{s}{1}.*(Ct{s}{1}>0); 
%     CD2=CD2.*Ct{s}{2}.*(Ct{s}{2}>0); 
%     CD3=CD3.*Ct{s}{3}.*(Ct{s}{3}>0);
    CD1=CD1.*Ct{s}{1}; 
    CD2=CD2.*Ct{s}{2}; 
    CD3=CD3.*Ct{s}{3};
end

CD=CD3;B=CD;
switch md
    case 1
        CD = CD1;B=CD2;
    case 2
        CD = CD2;B=CD1;
end

    case 3
n = size(img,1);F = ones(n);
X = fftshift(ifft2(F)) * sqrt(prod(size(F)));
C = usvt2D(X, J); 
E = cell(size(C));
for s=1:length(C)-1
    E{s} = cell(size(C{s}));
    for w=1:length(C{s})
        A = C{s}{w};
        E{s}{w} = sqrt(sum(sum(A.*conj(A))) / prod(size(A)));
    end
end
[C,p] = usvt2D(img, J);
Ct = C; 
p{1}=p{1}+(p{1}==0);tmp = Ct{1}{1}./p{s};Nsig = median(abs(tmp(:)))/0.6745;thresh=Msig;
for s = 1:J
    p{s}=p{s}+(p{s}==0);
    tmp=Ct{s}{1}./p{s};;
    Ct{s}{1} = (tmp.* (abs(tmp) > thresh*E{s}{1})).*p{s};
    tmp=Ct{s}{2}./p{s};;
    Ct{s}{2} = (tmp.* (abs(tmp) > thresh*E{s}{2})).*p{s};
    tmp=Ct{s}{3}./p{s};;
    Ct{s}{3} = (tmp.* (abs(tmp) > thresh*E{s}{3})).*p{s};
end

CD1=C{1}{3}.*0+1;CD2=CD1;CD3=CD1;B1=CD1.*0;
for s = 1:J
    CD1=CD1.*Ct{s}{1}; 
    CD2=CD2.*Ct{s}{2}; 
    CD3=CD3.*Ct{s}{3};
end

CD=CD3;B=CD;
switch md
    case 1
        CD = CD1;B=CD2;
    case 2
        CD = CD2;B=CD1;
end


end
% restored_img = iusvt2D(Ct, J);
return


function [restored_img,B,Nsig,E]=N_usvt2d_denoise(X,noisy_img,sigma,J,a,b)
% sigma=1; G=fspecial('gaussian',15,sigma);noisy_img=conv2(noisy_img,G,'same'); 
sigma=1;    % scale parameter in Gaussian kernel for smoothing.
G=fspecial('gaussian',15,sigma);
n = size(img,1);F = ones(n);
X = fftshift(ifft2(F)) * sqrt(prod(size(F)));
C = usvt2D(X, J); Nsig=0;
E = cell(size(C));
for s=1:length(C)-1
    E{s} = cell(size(C{s}));
    for w=1:length(C{s})
        A = C{s}{w};
        E{s}{w} = sqrt(sum(sum(A.*conj(A))) / prod(size(A)));
    end
end
C = usvt2D(noisy_img, J); 
if isempty(sigma); tmp = C{1}{3};Nsig = median(abs(tmp(:)))/0.6745,sigma=3*Nsig;end
% tmp = C{1}{3};Nsig = median(abs(tmp(:)))/0.6745,%sigma=b*Nsig;
% Apply thresholding
Ct = C;th=[1.0,0.5,0.0,0,0,0];
for s = 1:length(C)-1
%   thresh = a*sigma + (3.35-a)*sigma*(s==1);
  thresh = a*sigma + b*sigma*th(s);
  for w = 1:length(C{s})
      img=conv2(C{s}{w},G,'same'); 

    Ct{s}{w} = sign(C{s}{w}).*img.* (abs(C{s}{w}) > thresh*E{s}{w});
  end
end

%disp('Take inverse transform of thresholded data: ifdct_wrapping');
B=Ct{J+1};
restored_img = iusvt2D(Ct, J);
return
