function [ output_args ] = DSVT_demo( input_args )
% Copyright (c) by Changcai Yang
% 
% A demo of small target detection
%
% The small target detection technique is based on the following paper:
% 	Changcai Yang, Jiayi Ma, Sheng Zheng, Xin Tian. ��Multiscale Facet Model	for Infrared Small Target Detection��. Infrared Physics & Technology. 2014, 67:202-209. 
% Changcai Yang, Jiayi Ma, Shengxiang Qi, Jinwen Tian, Sheng Zheng, and Xin Tian. Directional Support Value of Gaussian Transformation for Infrared Small Target Detection. Applied Optics, 2015, 54(9): 2255-2265
% https://sites.google.com/site/changcaiyang/

close all;clear all
%
loadpath ='.\InfraredImage\Airplane\'
%% 
savepath = '.\result_sequence\Airplane\';
dirname  = dir(strcat(loadpath,'*.bmp'));
  %nub_ok=[5 9 15 22 25 26];
% for namei =nub_ok  
for namei = 1 : length(dirname)

%% Read image
I_rgb = imread([loadpath dirname(namei).name]);
picname = dirname(namei).name;
picname = picname(1:(find(picname=='.')-1));
[origH, origW, origD] = size(I_rgb);
if origD==3
    I_rgb = rgb2gray(I_rgb);
end
% imwrite(I_rgb(3:(origH-2),3:(origW-2)),[savepath picname '_A.jpg'],'jpg');
img = mat2gray(double(I_rgb));

J=4;

tic;
%%  E_T,E_Tsc: trace of the SVM;E_D,E_Dsc:determinant of the SVM
[E_T,E_D,E_Tsc,E_Dsc] = ust2d_denoise_detection_all(img,J);

OutImg_Dsc=E_Dsc{J+1};
OutImg_Dsc = OutImg_Dsc(3:(origH-2),3:(origW-2));
imwrite(mat2gray(OutImg_Dsc),[savepath picname '_CTMsc.jpg'],'jpg');


disp(['completed number:' num2str(namei)])
end
% save(['tim_' method1 method2 '_resca'],'tim_CDM','tim_CTM');
% fprintf('It is done.\n');

% end

msgbox('It is done��')
end

