function [E_T,E_D,E_Tsc,E_Dsc,F] = ust2d_denoise_detection_all(img,J)

% C{1}:S_j^{vv};C{2}:S_j^{hh};C{3}:S_j^{vh};C{5}:I_{j+1}
[C] = usvt2d(img, J); 
Ct = C;%S^{vv}:Ct{1};S^{hh}:Ct{2};S^{vh}:Ct{3};
[E_T,E_D,E_Tsc,E_Dsc,F] = iusvt2D(Ct, J);
   
    
return
function [E_T,E_D,E_Tsc,E_Dsc,F]=iusvt2D(w,J)
% y=w{J+1}.*0; %inverse the directional support value transfrom
% for k = 1:J
%    for s=1:3
%     y=y+w{k}{s};
%    end
% end
% CD1=w{1}{3}.*0+1;CD2=CD1;CD3=CD1;
% for s = 1:J %multiscale product of thw wavelet coefficients
%     CD1=CD1.*w{s}{1}; 
%     CD2=CD2.*w{s}{2}; 
%     CD3=CD3.*w{s}{3};
% end
% C{1}=CD1;C{2}=CD2;C{3}=CD3;

D=w{1}{3}.*0+1;
G_D=D;
G_T=D;
G_Dsc=D;
G_Tsc=D;
 F=D;
for s =1:1:J
    D1=w{s}{1}.*w{s}{2}-w{s}{3}.*w{s}{3}; %determinant
    D2=w{s}{2}+w{s}{1}; %trace
    T1=abs(D2)/s^2;
    T1sc=s^2*T1;
%     D1=s^2*abs(w{s}{2}+w{s}{1});
    if s==1
        D3=1;
    else
%         D3=(D1>0).*(D2>0); %geometrical property combine the deerminant
%         and trace
%         D3=(D1>0).*(T1>0); %geometrical property combine the deerminant
%         and trace
     D1=rescale(D1,0,10);
     T1=rescale(T1,0,10);
        D3=2*D1+T1; %geometrical property combine the deerminant and trace
    end    
%E_T,E_D,E_Tn,E_Dn
    D1sc=s^2*D1;
%     E{s}=s^2*D1;
     E_D{s}=D1;
     E_Tsc{s}=T1sc;
     E_T{s}=D2;
     E_Dsc{s}=D1sc;
% %     D1=rescale(D1,0,10); %normalization
%      D1=rescale(D1,0,10);
%      T1=rescale(T1,0,10);
    G_D=G_D.*D1; %automatical scale selecton
    G_T=G_T.*T1;
    G_Dsc=G_Dsc.*D1sc;
    G_Tsc=G_Tsc.*T1sc;
    F=F.*D3;
    
end
% G=rescale(G,0,10);
E_D{J+1}=G_D;%max(G-mean2(G),G.*0);
E_Dsc{J+1}=G_Dsc;
E_T{J+1}=G_T;
E_Tsc{J+1}=G_Tsc;

% E{J+2}=F;
return

function [y]=iuasvt(w,J)
y=w{J+1}.*0;
for k = 1:J
    y=y+w{k};
end
return

function y = rescale(x,a,b)

    % rescale - rescale data in [a,b]
    %
    %   y = rescale(x,a,b);
    %
    %   Copyright (c) 2004 Gabriel Peyr?

    if nargin<2
        a = 0;
    end
    if nargin<3
        b = 1;
    end

    m = min(x(:));
    M = max(x(:));

    if M-m<eps
        y = x;
    else
        y = (b-a) * (x-m)/(M-m) + a;
    end
return

function [M,p] = usvt(M1,J,mt);
switch mt
    case 1
f1=[1/256 1/64 3/128 1/64 1/256;1/64 1/16 3/32 1/16 1/64;3/128 3/32 9/64 3/32 3/128;1/64 1/16 3/32 1/16 1/64;1/256 1/64 3/128 1/64 1/256];
fs=f1.*0+1;
for j=1:J
  f2=fexp(f1,j-1);f2s=fexp(fs,j-1);
  M1B = imfilter(M1,f2,'replicate');
  M{j}=M1-M1B;M1=M1B;
  p{j}=imfilter(M1,f2s,'replicate');p{j}=sqrt(abs(p{j}));
end
M{J+1}=M1;
    case 2
f1=[ -0.0158   -0.0136   -0.0102   -0.0136   -0.0158;...
    -0.0136   -0.0130   -0.0602   -0.0130   -0.0136; ...
    -0.0102   -0.0602    0.5051   -0.0602   -0.0102; ...
    -0.0136   -0.0130   -0.0602   -0.0130   -0.0136;...
    -0.0158   -0.0136   -0.0102   -0.0136   -0.0158];
%j=1; gama=1;sig2=0.0.6*2^j;n=2^j;p1=1;p2=0;step=1;[AXK,XK,XK1,XK2,XK1T,XK2T,XK11T,XK22T,XK12T,XKKT,B] = ikernel(n,p1,p2,sig2,gama,step);l=2*n+1;l=l^2; OPK=AXK(round(l/2),:);f1=reshape(OPK,2*n+1,2*n+1),
%support value transfrom
fs=f1.*0+1;
for j=1:J
  f2=fexp(f1,j-1);f2s=fexp(fs,j-1);
  M{j} = imfilter(M1,f2,'replicate');
  M1=M1-M{j};
  p{j}=imfilter(M1,f2s,'replicate');
end
M{J+1}=M1;
end
return
