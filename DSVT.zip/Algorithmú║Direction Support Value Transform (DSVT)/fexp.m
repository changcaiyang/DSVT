function [f3]=fexp(f1,s)
[m n]=size(f1);
zr=repmat(0,1,m);
f2(1,:)=f1(1,:);
j=1;
for i=2:m
    for k=1:s,j=j+1; f2(j,:)=zr;end
    j=j+1;f2(j,:)=f1(i,:);
end
[z m]=size(f2);
zr=repmat(0,z,1);
f3(:,1)=f2(:,1);
j=1;
for i=2:m
    for k=1:s,j=j+1; f3(:,j)=zr;end
    j=j+1;f3(:,j)=f2(:,i);
end
return