function [w,p]=usvt2D(x, J, af1)
if nargin < 3
af1=[-0.0000   -0.0000   -0.0000   -0.0000   -0.0000;...
   -0.0077   -0.0166   -0.0350   -0.0166   -0.0077;...
   -0.0255   -0.1680    0.5548   -0.1680   -0.0255;...
   -0.0077   -0.0166   -0.0350   -0.0166   -0.0077;...
   -0.0000   -0.0000   -0.0000   -0.0000   -0.0000];
% af1 =[0.0055   -0.0555   -0.1001   -0.0555    0.0055;...
%     0.0055   -0.0555   -0.1001   -0.0555    0.0055;...
%     0.0055   -0.0555    0.8999   -0.0555    0.0055;...
%     0.0055   -0.0555   -0.1001   -0.0555    0.0055;...
%     0.0055   -0.0555   -0.1001   -0.0555    0.0055]';
% af1=[0.0171   -0.0685   -0.0971   -0.0685    0.0171;...
%     0.0171   -0.0685   -0.0971   -0.0685    0.0171;...
%     0.0171   -0.0685    0.9029   -0.0685    0.0171;...
%     0.0171   -0.0685   -0.0971   -0.0685    0.0171;...
%     0.0171   -0.0685   -0.0971   -0.0685    0.0171];

end
afs=af1.*0+1;
for k = 1:J
    af=fexp(af1,k-1);
    af2s=fexp(afs,k-1);
    % w{1}:S_j^{vv};w{2}:S_j^{hh};w{3}:S_j^{vh};x:I_{j+1}
    [x w{k}] = svtb2D(x, af, af');
    p{k}=imfilter(x,af2s,'replicate');
    p{k}=sqrt(abs(p{k}));
end
w{J+1} = x;
return

function [y]=iusvt2D(w,J)
y=w{J+1};
for k = 1:J
   for s=1:3
    y=y+w{k}{s};
   end
end
return

function [lo, hi] = svtb2D(x, af1, af2)
% 2D Analysis Filter Bank
%% hi{1}:S_j^{vv};hi{3}:S_j^{vh};hi{2}:S_j^{hh};lo:I_{j+1}
% USAGE:
%   [lo, hi] = afb2D(x, af1, af2);
% INPUT:
%   x - N by M matrix
%   af1 - analysis filters for columns
%   af2 - analysis filters for rows
% OUTPUT:
%    lo - lowpass subband
%    hi{1} - 'lohi' subband
%    hi{2} - 'hilo' subband
%    hi{3} - 'hihi' subband

if nargin < 3
   af2 = af1;
end
% filter along columns
%[L, H] = afb2D_A(x, af1, 1);
H = imfilter(x,af1,'replicate');L=x-H;%H:S_j^{h};L:S_j^{v};

% filter along rows
% [lo,    hi{1}] = afb2D_A(L, af2, 2);
% [hi{2}, hi{3}] = afb2D_A(H, af2, 2);
hi{1} = imfilter(L,af2,'replicate');lo=L-hi{1};%
hi{3} = imfilter(H,af2,'replicate');hi{2}=H-hi{3}; 
return


