Please cite the following paper when you use this code.

[1] Changcai Yang, Jiayi Ma, Shengxiang Qi, Jinwen Tian, Sheng Zheng, and Xin Tian. Directional Support Value of Gaussian Transformation for Infrared Small Target Detection. Applied Optics, 2015, 54(9): 2255-2265. 
[2] Changcai Yang, Jiayi Ma, Sheng Zheng, Xin Tian. Multiscale Facet Model for Infrared Small Target Detection. Infrared Physics & Technology, 2014, 67: 202-209. 
