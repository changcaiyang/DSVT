function [ output_args ] = DSVT_demo( input_args )
% Copyright (c) by Changcai Yang
% 
% A demo of small target detection
%
% The small target detection technique is based on the following paper:
% 	Changcai Yang, Jiayi Ma, Sheng Zheng, Xin Tian. ��Multiscale Facet Model	for Infrared Small Target Detection��. Infrared Physics & Technology. 2014, 67:202-209. 
% https://sites.google.com/site/changcaiyang/

close all;clear all
%
% loadpath ='.\InfraredImage\Airplane\'
%% 
% savepath = '.\result_sequence\Airplane\';

loadpath ='J:\paper-2017\markers\Marker-based-XROMM\Pig-Feeding-Example2015\20061229susDFc01S0001-00Mirroredshorter.avi-JPG\'
savepath = '.\results_marker\';

% dirname  = dir(strcat(loadpath,'*.bmp'));
dirname  = dir(strcat(loadpath,'*.jpg'));
  %nub_ok=[5 9 15 22 25 26];
% for namei =nub_ok  
for namei = 1 %: length(dirname)

%% Read image
I_rgb = imread([loadpath dirname(namei).name]);


% I_rgb = imread('J:\paper-2017\markers\Marker-based XROMM\Pig Feeding Example 2015\20061229susDFc01S0001-00Mirroredshorter.avi-JPG\20061229susDFc01S0001-00Mirroredshorter.00001.jpg');

picname = dirname(namei).name;
picname = picname(1:(find(picname=='.')-1));
[origH, origW, origD] = size(I_rgb);
if origD==3
    I_rgb = rgb2gray(I_rgb);
end
I_rgb=I_rgb(415:685,390:824);
[origH, origW, origD] = size(I_rgb);

% imwrite(I_rgb(3:(origH-2),3:(origW-2)),[savepath picname '_A.jpg'],'jpg');
img = mat2gray(double(I_rgb));
img = 1-mat2gray(double(img));
figure,imshow(img);
% img = histeq(img,256);
% w4=fspecial('laplacian',0);
% w8=[1 1 1;1 -8 1;1 1 1];
% g8=img-imfilter(img,w4,'replicate');
% img=imresize(img,2);
% figure,imshow(g8);
J=4;

tic;
%%  E_T,E_Tsc: trace of the SVM;E_D,E_Dsc:determinant of the SVM
[E_T,E_D,E_Tsc,E_Dsc,F] = ust2d_denoise_detection_all(img,J);

OutImg_Dsc=E_Dsc{J+1};
OutImg_Dsc = OutImg_Dsc(3:(origH-2),3:(origW-2));
imwrite(mat2gray(OutImg_Dsc),[savepath picname '_CTMsc.jpg'],'jpg');

figure,imshow(mat2gray(OutImg_Dsc));
figure,imshow(mat2gray(F));
disp(['completed number:' num2str(namei)])
end
% save(['tim_' method1 method2 '_resca'],'tim_CDM','tim_CTM');
% fprintf('It is done.\n');

% end

msgbox('It is done��')
end

